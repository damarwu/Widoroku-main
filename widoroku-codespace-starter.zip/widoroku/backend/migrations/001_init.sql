CREATE TABLE IF NOT EXISTS residents (
 id BIGSERIAL PRIMARY KEY, house_code TEXT NOT NULL UNIQUE, head_name TEXT NOT NULL,
 address TEXT NOT NULL DEFAULT '', qr_token TEXT NOT NULL UNIQUE, active BOOLEAN NOT NULL DEFAULT TRUE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS periods (
 id BIGSERIAL PRIMARY KEY, start_date DATE NOT NULL, meeting_date DATE NOT NULL UNIQUE,
 status TEXT NOT NULL CHECK(status IN ('TERJADWAL','TERLAKSANA','LIBUR')), note TEXT NOT NULL DEFAULT '', created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS bills (
 id BIGSERIAL PRIMARY KEY, resident_id BIGINT NOT NULL REFERENCES residents(id), period_id BIGINT NOT NULL REFERENCES periods(id),
 description TEXT NOT NULL, amount BIGINT NOT NULL CHECK(amount>=0), created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 UNIQUE(resident_id,period_id,description)
);
CREATE TABLE IF NOT EXISTS payments (
 id BIGSERIAL PRIMARY KEY, resident_id BIGINT NOT NULL REFERENCES residents(id), amount BIGINT NOT NULL CHECK(amount>0),
 note TEXT NOT NULL DEFAULT '', received_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS payment_allocations (
 id BIGSERIAL PRIMARY KEY, payment_id BIGINT NOT NULL REFERENCES payments(id), bill_id BIGINT NOT NULL REFERENCES bills(id),
 amount BIGINT NOT NULL CHECK(amount>0), created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS jimpitan_transactions (
 id BIGSERIAL PRIMARY KEY, resident_id BIGINT NOT NULL REFERENCES residents(id), session_date DATE NOT NULL,
 amount BIGINT NOT NULL CHECK(amount>=0), status TEXT NOT NULL CHECK(status IN ('TERAMBIL','KOSONG','TIDAK_DAPAT_DIAMBIL')),
 note TEXT NOT NULL DEFAULT '', created_at TIMESTAMPTZ NOT NULL DEFAULT now(), UNIQUE(resident_id,session_date)
);
CREATE TABLE IF NOT EXISTS tabungan_transactions (
 id BIGSERIAL PRIMARY KEY, group_name TEXT NOT NULL, member_name TEXT NOT NULL,
 amount BIGINT NOT NULL CHECK(amount<>0), type TEXT NOT NULL CHECK(type IN ('SETOR','TARIK')),
 note TEXT NOT NULL DEFAULT '', created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_bills_resident_period ON bills(resident_id,period_id);
CREATE INDEX IF NOT EXISTS idx_jimpitan_session ON jimpitan_transactions(session_date);
