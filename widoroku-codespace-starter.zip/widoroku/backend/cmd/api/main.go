package main

import (
	"context"
	"encoding/json"
	"errors"
	"log"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

type App struct{ db *pgxpool.Pool }
type Resident struct {
	ID        int64  `json:"id"`
	HouseCode string `json:"house_code"`
	HeadName  string `json:"head_name"`
	Address   string `json:"address"`
	QRToken   string `json:"qr_token"`
}
type Period struct {
	ID          int64  `json:"id"`
	StartDate   string `json:"start_date"`
	MeetingDate string `json:"meeting_date"`
	Status      string `json:"status"`
	Note        string `json:"note"`
}
type Bill struct {
	ID          int64  `json:"id"`
	ResidentID  int64  `json:"resident_id"`
	PeriodID    int64  `json:"period_id"`
	Description string `json:"description"`
	Amount      int64  `json:"amount"`
	Paid        int64  `json:"paid"`
	Remaining   int64  `json:"remaining"`
}
type PaymentInput struct {
	ResidentID int64  `json:"resident_id"`
	Amount     int64  `json:"amount"`
	Note       string `json:"note"`
}
type JimpitanInput struct {
	QRToken     string `json:"qr_token"`
	SessionDate string `json:"session_date"`
	Amount      int64  `json:"amount"`
	Status      string `json:"status"`
	Note        string `json:"note"`
}
type TabunganInput struct {
	GroupName  string `json:"group_name"`
	MemberName string `json:"member_name"`
	Amount     int64  `json:"amount"`
	Type       string `json:"type"`
	Note       string `json:"note"`
}

func main() {
	dsn := os.Getenv("DATABASE_URL")
	if dsn == "" {
		dsn = "postgres://widoroku:widoroku-dev-password@localhost:5432/widoroku?sslmode=disable"
	}
	ctx := context.Background()
	var pool *pgxpool.Pool
	var err error
	for i := 0; i < 20; i++ {
		pool, err = pgxpool.New(ctx, dsn)
		if err == nil {
			err = pool.Ping(ctx)
			if err == nil {
				break
			}
			pool.Close()
		}
		time.Sleep(2 * time.Second)
	}
	if err != nil {
		log.Fatalf("database connection failed: %v", err)
	}
	defer pool.Close()
	app := &App{db: pool}
	mux := http.NewServeMux()
	mux.HandleFunc("GET /api/health", app.health)
	mux.HandleFunc("GET /api/dashboard", app.dashboard)
	mux.HandleFunc("GET /api/residents", app.residents)
	mux.HandleFunc("POST /api/residents", app.createResident)
	mux.HandleFunc("GET /api/periods", app.periods)
	mux.HandleFunc("POST /api/periods", app.createPeriod)
	mux.HandleFunc("POST /api/periods/{id}/generate-bills", app.generateBills)
	mux.HandleFunc("GET /api/bills", app.bills)
	mux.HandleFunc("POST /api/payments", app.payment)
	mux.HandleFunc("POST /api/jimpitan", app.jimpitan)
	mux.HandleFunc("GET /api/jimpitan", app.jimpitanList)
	mux.HandleFunc("POST /api/tabungan", app.tabungan)
	mux.HandleFunc("GET /api/tabungan", app.tabunganList)
	handler := cors(mux)
	port := os.Getenv("API_PORT")
	if port == "" {
		port = "8080"
	}
	log.Printf("Widoroku API listening on :%s", port)
	log.Fatal(http.ListenAndServe(":"+port, handler))
}
func cors(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Access-Control-Allow-Origin", "*")
		w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")
		w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
		if r.Method == http.MethodOptions {
			w.WriteHeader(http.StatusNoContent)
			return
		}
		next.ServeHTTP(w, r)
	})
}
func jsonOut(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}
func jsonIn(r *http.Request, v any) error {
	defer r.Body.Close()
	return json.NewDecoder(r.Body).Decode(v)
}
func (a *App) health(w http.ResponseWriter, r *http.Request) {
	if err := a.db.Ping(r.Context()); err != nil {
		jsonOut(w, 503, map[string]string{"status": "database unavailable"})
		return
	}
	jsonOut(w, 200, map[string]string{"status": "ok", "service": "widoroku-api"})
}
func (a *App) dashboard(w http.ResponseWriter, r *http.Request) {
	var residents int
	var bills int
	var outstanding int64
	var collected int64
	_ = a.db.QueryRow(r.Context(), "SELECT count(*) FROM residents WHERE active=true").Scan(&residents)
	_ = a.db.QueryRow(r.Context(), "SELECT count(*) FROM bills").Scan(&bills)
	_ = a.db.QueryRow(r.Context(), "SELECT COALESCE(sum(amount-paid),0) FROM bills").Scan(&outstanding)
	_ = a.db.QueryRow(r.Context(), "SELECT COALESCE(sum(amount),0) FROM payments").Scan(&collected)
	jsonOut(w, 200, map[string]any{"residents": residents, "bills": bills, "outstanding": outstanding, "payments_total": collected})
}
func (a *App) residents(w http.ResponseWriter, r *http.Request) {
	rows, err := a.db.Query(r.Context(), "SELECT id,house_code,head_name,address,qr_token FROM residents WHERE active=true ORDER BY house_code")
	if err != nil {
		fail(w, err)
		return
	}
	defer rows.Close()
	out := []Resident{}
	for rows.Next() {
		var x Resident
		if err := rows.Scan(&x.ID, &x.HouseCode, &x.HeadName, &x.Address, &x.QRToken); err != nil {
			fail(w, err)
			return
		}
		out = append(out, x)
	}
	jsonOut(w, 200, out)
}
func (a *App) createResident(w http.ResponseWriter, r *http.Request) {
	var x Resident
	if jsonIn(r, &x) != nil || strings.TrimSpace(x.HouseCode) == "" || strings.TrimSpace(x.HeadName) == "" {
		jsonOut(w, 400, map[string]string{"error": "house_code dan head_name wajib diisi"})
		return
	}
	if x.QRToken == "" {
		x.QRToken = "WDR-" + strings.ToUpper(strings.ReplaceAll(x.HouseCode, " ", "-"))
	}
	err := a.db.QueryRow(r.Context(), "INSERT INTO residents(house_code,head_name,address,qr_token) VALUES($1,$2,$3,$4) RETURNING id", x.HouseCode, x.HeadName, x.Address, x.QRToken).Scan(&x.ID)
	if err != nil {
		fail(w, err)
		return
	}
	jsonOut(w, 201, x)
}
func (a *App) periods(w http.ResponseWriter, r *http.Request) {
	rows, err := a.db.Query(r.Context(), "SELECT id,start_date::text,meeting_date::text,status,note FROM periods ORDER BY meeting_date DESC")
	if err != nil {
		fail(w, err)
		return
	}
	defer rows.Close()
	out := []Period{}
	for rows.Next() {
		var p Period
		if err := rows.Scan(&p.ID, &p.StartDate, &p.MeetingDate, &p.Status, &p.Note); err != nil {
			fail(w, err)
			return
		}
		out = append(out, p)
	}
	jsonOut(w, 200, out)
}
func (a *App) createPeriod(w http.ResponseWriter, r *http.Request) {
	var p Period
	if jsonIn(r, &p) != nil || p.StartDate == "" || p.MeetingDate == "" {
		jsonOut(w, 400, map[string]string{"error": "start_date dan meeting_date wajib diisi (YYYY-MM-DD)"})
		return
	}
	p.Status = strings.ToUpper(p.Status)
	if p.Status == "" {
		p.Status = "TERJADWAL"
	}
	if p.Status != "TERJADWAL" && p.Status != "TERLAKSANA" && p.Status != "LIBUR" {
		jsonOut(w, 400, map[string]string{"error": "status harus TERJADWAL, TERLAKSANA, atau LIBUR"})
		return
	}
	err := a.db.QueryRow(r.Context(), "INSERT INTO periods(start_date,meeting_date,status,note) VALUES($1,$2,$3,$4) RETURNING id", p.StartDate, p.MeetingDate, p.Status, p.Note).Scan(&p.ID)
	if err != nil {
		fail(w, err)
		return
	}
	jsonOut(w, 201, p)
}
func (a *App) generateBills(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil {
		jsonOut(w, 400, map[string]string{"error": "invalid period id"})
		return
	}
	tx, err := a.db.Begin(r.Context())
	if err != nil {
		fail(w, err)
		return
	}
	defer tx.Rollback(r.Context())
	var status string
	if err = tx.QueryRow(r.Context(), "SELECT status FROM periods WHERE id=$1 FOR UPDATE", id).Scan(&status); err != nil {
		fail(w, err)
		return
	}
	if status != "TERLAKSANA" {
		jsonOut(w, 409, map[string]string{"error": "tagihan hanya dapat dibuat jika kumpulan berstatus TERLAKSANA; kumpulan LIBUR tidak ditagih"})
		return
	}
	tag, err := tx.Exec(r.Context(), "INSERT INTO bills(resident_id,period_id,description,amount) SELECT r.id,$1,'Iuran kumpulan',25000 FROM residents r WHERE r.active=true ON CONFLICT(resident_id,period_id,description) DO NOTHING", id)
	if err != nil {
		fail(w, err)
		return
	}
	if err = tx.Commit(r.Context()); err != nil {
		fail(w, err)
		return
	}
	jsonOut(w, 200, map[string]any{"created_or_existing": tag.RowsAffected(), "period_id": id, "message": "Tagihan iuran kumpulan dibuat; nominal contoh Rp25.000 dapat dikonfigurasi pada tahap berikutnya."})
}
func (a *App) bills(w http.ResponseWriter, r *http.Request) {
	rows, err := a.db.Query(r.Context(), "SELECT b.id,b.resident_id,b.period_id,b.description,b.amount,COALESCE(sum(pa.amount),0)::bigint,b.amount-COALESCE(sum(pa.amount),0)::bigint FROM bills b LEFT JOIN payment_allocations pa ON pa.bill_id=b.id GROUP BY b.id ORDER BY b.id DESC")
	if err != nil {
		fail(w, err)
		return
	}
	defer rows.Close()
	out := []Bill{}
	for rows.Next() {
		var b Bill
		if err := rows.Scan(&b.ID, &b.ResidentID, &b.PeriodID, &b.Description, &b.Amount, &b.Paid, &b.Remaining); err != nil {
			fail(w, err)
			return
		}
		out = append(out, b)
	}
	jsonOut(w, 200, out)
}
func (a *App) payment(w http.ResponseWriter, r *http.Request) {
	var p PaymentInput
	if jsonIn(r, &p) != nil || p.ResidentID < 1 || p.Amount < 1 {
		jsonOut(w, 400, map[string]string{"error": "resident_id dan amount positif wajib diisi"})
		return
	}
	tx, err := a.db.Begin(r.Context())
	if err != nil {
		fail(w, err)
		return
	}
	defer tx.Rollback(r.Context())
	var paymentID int64
	err = tx.QueryRow(r.Context(), "INSERT INTO payments(resident_id,amount,note) VALUES($1,$2,$3) RETURNING id", p.ResidentID, p.Amount, p.Note).Scan(&paymentID)
	if err != nil {
		fail(w, err)
		return
	}
	remaining := p.Amount
	rows, err := tx.Query(r.Context(), "SELECT b.id,b.amount-COALESCE((SELECT sum(pa.amount) FROM payment_allocations pa WHERE pa.bill_id=b.id),0)::bigint AS due FROM bills b WHERE b.resident_id=$1 AND b.amount>COALESCE((SELECT sum(pa.amount) FROM payment_allocations pa WHERE pa.bill_id=b.id),0) ORDER BY b.period_id,b.id FOR UPDATE", p.ResidentID)
	if err != nil {
		fail(w, err)
		return
	}
	type dueRow struct {
		id  int64
		due int64
	}
	due := []dueRow{}
	for rows.Next() {
		var d dueRow
		if err = rows.Scan(&d.id, &d.due); err != nil {
			rows.Close()
			fail(w, err)
			return
		}
		due = append(due, d)
	}
	rows.Close()
	if len(due) == 0 {
		jsonOut(w, 409, map[string]string{"error": "warga tidak memiliki tagihan yang belum lunas"})
		return
	}
	var allocated int64
	for _, d := range due {
		if remaining == 0 {
			break
		}
		n := d.due
		if n > remaining {
			n = remaining
		}
		_, err = tx.Exec(r.Context(), "INSERT INTO payment_allocations(payment_id,bill_id,amount) VALUES($1,$2,$3)", paymentID, d.id, n)
		if err != nil {
			fail(w, err)
			return
		}
		remaining -= n
		allocated += n
	}
	if remaining > 0 {
		jsonOut(w, 400, map[string]any{"error": "pembayaran melebihi total tunggakan", "max_payable": allocated})
		return
	}
	if err = tx.Commit(r.Context()); err != nil {
		fail(w, err)
		return
	}
	jsonOut(w, 201, map[string]any{"payment_id": paymentID, "received": p.Amount, "allocated": allocated, "remaining_unallocated": remaining, "message": "Pembayaran dialokasikan ke tagihan terlama terlebih dahulu."})
}
func (a *App) jimpitan(w http.ResponseWriter, r *http.Request) {
	var x JimpitanInput
	if jsonIn(r, &x) != nil || x.QRToken == "" || x.SessionDate == "" {
		jsonOut(w, 400, map[string]string{"error": "qr_token dan session_date wajib diisi"})
		return
	}
	if x.Amount < 0 {
		jsonOut(w, 400, map[string]string{"error": "amount tidak boleh negatif"})
		return
	}
	if x.Status == "" {
		x.Status = "TERAMBIL"
	}
	var id int64
	err := a.db.QueryRow(r.Context(), "INSERT INTO jimpitan_transactions(resident_id,session_date,amount,status,note) SELECT id,$2,$3,$4,$5 FROM residents WHERE qr_token=$1 RETURNING id", x.QRToken, x.SessionDate, x.Amount, x.Status, x.Note).Scan(&id)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			jsonOut(w, 404, map[string]string{"error": "QR rumah tidak ditemukan"})
			return
		}
		fail(w, err)
		return
	}
	jsonOut(w, 201, map[string]any{"id": id, "message": "Catatan jimpitan tersimpan"})
}
func (a *App) jimpitanList(w http.ResponseWriter, r *http.Request) {
	rows, err := a.db.Query(r.Context(), "SELECT j.id,r.house_code,r.head_name,j.session_date::text,j.amount,j.status,j.note FROM jimpitan_transactions j JOIN residents r ON r.id=j.resident_id ORDER BY j.session_date DESC,j.id DESC LIMIT 200")
	if err != nil {
		fail(w, err)
		return
	}
	defer rows.Close()
	type item struct {
		ID        int64  `json:"id"`
		HouseCode string `json:"house_code"`
		HeadName  string `json:"head_name"`
		Date      string `json:"date"`
		Amount    int64  `json:"amount"`
		Status    string `json:"status"`
		Note      string `json:"note"`
	}
	out := []item{}
	for rows.Next() {
		var x item
		if err := rows.Scan(&x.ID, &x.HouseCode, &x.HeadName, &x.Date, &x.Amount, &x.Status, &x.Note); err != nil {
			fail(w, err)
			return
		}
		out = append(out, x)
	}
	jsonOut(w, 200, out)
}
func (a *App) tabungan(w http.ResponseWriter, r *http.Request) {
	var x TabunganInput
	if jsonIn(r, &x) != nil || x.GroupName == "" || x.MemberName == "" || x.Amount < 1 {
		jsonOut(w, 400, map[string]string{"error": "group_name, member_name, amount positif wajib diisi"})
		return
	}
	if x.Type == "" {
		x.Type = "SETOR"
	}
	if x.Type != "SETOR" && x.Type != "TARIK" {
		jsonOut(w, 400, map[string]string{"error": "type harus SETOR atau TARIK"})
		return
	}
	amount := x.Amount
	if x.Type == "TARIK" {
		amount = -amount
	}
	var id int64
	err := a.db.QueryRow(r.Context(), "INSERT INTO tabungan_transactions(group_name,member_name,amount,type,note) VALUES($1,$2,$3,$4,$5) RETURNING id", x.GroupName, x.MemberName, amount, x.Type, x.Note).Scan(&id)
	if err != nil {
		fail(w, err)
		return
	}
	jsonOut(w, 201, map[string]any{"id": id, "message": "Transaksi tabungan tersimpan"})
}
func (a *App) tabunganList(w http.ResponseWriter, r *http.Request) {
	rows, err := a.db.Query(r.Context(), "SELECT group_name,member_name,COALESCE(sum(amount),0)::bigint FROM tabungan_transactions GROUP BY group_name,member_name ORDER BY group_name,member_name")
	if err != nil {
		fail(w, err)
		return
	}
	defer rows.Close()
	type item struct {
		Group   string `json:"group_name"`
		Member  string `json:"member_name"`
		Balance int64  `json:"balance"`
	}
	out := []item{}
	for rows.Next() {
		var x item
		if err := rows.Scan(&x.Group, &x.Member, &x.Balance); err != nil {
			fail(w, err)
			return
		}
		out = append(out, x)
	}
	jsonOut(w, 200, out)
}
func fail(w http.ResponseWriter, err error) {
	log.Printf("request error: %v", err)
	jsonOut(w, 500, map[string]string{"error": "internal server error"})
}
