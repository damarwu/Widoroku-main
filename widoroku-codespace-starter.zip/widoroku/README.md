# Widoroku RT — Go API + Web/PWA

Starter project untuk administrasi RT: data warga, periode kumpulan 35 hari, tagihan, pembayaran cicilan/kolektif, jimpitan QR, tabungan jalan, ronda, dan laporan.

## Jalankan di GitHub Codespaces
1. Buat repository GitHub baru, upload seluruh isi folder ini, lalu pilih **Code → Codespaces → Create codespace**.
2. Di terminal Codespaces:
   ```bash
   docker compose up -d db
   cd backend && go mod tidy && cd ..
   docker compose up --build
   ```
3. Buka tab **Ports**, buka port `5173` untuk web dan `8080` untuk API. Web memakai proxy Vite ke API.
4. Cek API: `GET /api/health`.

## Database
PostgreSQL berjalan dalam service Docker `db`. Schema awal otomatis diterapkan dari `backend/migrations/001_init.sql` saat container pertama kali dibuat. Data lokal tersimpan pada volume `postgres_data`.

## Web / Android
- Web/PWA: frontend React + Vite; bisa dibuka dari browser HP dan dipasang sebagai PWA setelah konfigurasi manifest/service worker dilengkapi.
- Android/iOS: setelah UI stabil, tambahkan Capacitor (`npm install @capacitor/core @capacitor/cli`, `npx cap init`, `npm install @capacitor/android`, `npx cap add android`). Android build memerlukan Android Studio/SDK; Codespaces paling cocok untuk web/API, bukan emulator Android grafis.

## Catatan awal
- Ini starter/MVP, bukan sistem produksi siap pakai. Sebelum digunakan untuk uang nyata, lengkapi login dan otorisasi, audit trail, backup, HTTPS, pengujian transaksi, dan kebijakan privasi.
- Kumpulan libur tidak menghasilkan tagihan baru. Tunggakan lama tetap tersimpan dan boleh dicicil atau dilunasi.
- Tagihan periode dibuat hanya saat status kumpulan `TERLAKSANA`.
- Jangan memasukkan NIK atau data sensitif asli ke demo.

## Fitur yang sudah ada di starter
- Dashboard glossy hijau, responsif desktop dan HP.
- CRUD tambah warga/rumah dan QR token.
- Buat periode kumpulan berstatus TERJADWAL / TERLAKSANA / LIBUR.
- Pembuatan tagihan ditolak jika kumpulan bukan TERLAKSANA.
- Pembayaran/cicilan individual dialokasikan ke tagihan tertua.
- Pencatatan jimpitan memakai QR token, tanggal, nominal, dan hasil kunjungan.
- Input transaksi tabungan jalan dan ringkasan saldo peserta.

## Batasan MVP yang harus diketahui
- Nominal iuran Rp25.000 masih contoh hard-coded di endpoint pembuatan tagihan; jadikan konfigurasi sebelum dipakai.
- Pembayaran kolektif multi-KK, kamera QR langsung, login/role, penarikan tabungan dengan validasi saldo, modul ronda, dan laporan kas lengkap belum selesai.
- Service worker menyimpan shell aplikasi sederhana; ini bukan jaminan seluruh aplikasi berfungsi offline. Transaksi tetap memerlukan koneksi.
- Kalender Ahad Pon perlu diisi/validasi berdasarkan tanggal pasaran yang benar oleh admin; sistem tidak menebak pasaran secara otomatis.
